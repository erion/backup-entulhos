-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 15, 2009 as 01:21 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `rosana_imoveis`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(45) default NULL,
  `pessoa` enum('F','J') default NULL COMMENT 'F = FÃ­sica\nJ = Pessoa JurÃ­dica',
  `cpf_cnpj` varchar(16) default NULL,
  `cidade` varchar(45) default NULL,
  `uf` varchar(3) default NULL,
  `endereco` varchar(255) default NULL,
  `numero` varchar(10) default NULL,
  `apto` varchar(10) default NULL,
  `bairro` varchar(45) default NULL,
  `cep` varchar(9) default NULL,
  `telefone` varchar(12) default NULL,
  `celular` varchar(12) default NULL,
  `email` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`id`, `nome`, `pessoa`, `cpf_cnpj`, `cidade`, `uf`, `endereco`, `numero`, `apto`, `bairro`, `cep`, `telefone`, `celular`, `email`) VALUES
(1, 'Endel', 'F', '1231234', 'Sapiranga', 'RS', 'Monte Castelo', '442', '1214', 'São Luiz', '93800000', '97245163', '97245163', 'endel.dreyer@gmail.com'),
(2, 'Erion', 'F', '235235', 'Sapiranga', 'RS', 'Santa Helena', '72', NULL, 'Centenário', '93800000', '35598811', NULL, 'erion.dreyer@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_imovel`
--

CREATE TABLE `cliente_imovel` (
  `id` int(11) NOT NULL auto_increment,
  `cliente_id` int(11) default NULL,
  `comprador` tinyint(1) default NULL,
  `vendedor` tinyint(1) default NULL,
  `observacoes` text,
  PRIMARY KEY  (`id`),
  KEY `idx_cliente_imovel_cliente_id` (`cliente_id`),
  KEY `fk_cliente_imovel_cliente_id` (`cliente_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `cliente_imovel`
--

INSERT INTO `cliente_imovel` (`id`, `cliente_id`, `comprador`, `vendedor`, `observacoes`) VALUES
(1, 1, 1, 0, 'Observações aqui...'),
(2, 2, 0, 1, 'Obs...');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_posto`
--

CREATE TABLE `cliente_posto` (
  `id` int(11) NOT NULL auto_increment,
  `cliente_id` int(11) default NULL,
  `data` date default NULL,
  `anuncio` varchar(45) default NULL,
  `indicacao` varchar(45) default NULL,
  `ja_administrou` tinyint(1) default NULL,
  `quer_adquirir` enum('N','C','P') NOT NULL COMMENT '\nQuer adquirir propriedade ou fundo de comÃ©rcio? \nN = NÃ£o\nC = ComÃ©rcio\nP = Propriedade',
  `valor_investimento` double default NULL COMMENT 'Valor que pretende investir?',
  `regiao_investimento` varchar(45) default NULL COMMENT 'Qual\n regiÃ£o que deseja investir?',
  PRIMARY KEY  (`id`),
  KEY `idx_cliente_posto_cliente` (`cliente_id`),
  KEY `fk_cliente_posto_cliente` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `cliente_posto`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `imovel`
--

CREATE TABLE `imovel` (
  `id` int(11) NOT NULL auto_increment,
  `categoria` int(11) default NULL,
  `modalidade` enum('A','V') default NULL COMMENT 'A = Aluguel\nV = Venda',
  `construcao` enum('ALV','MAD','MIS') default NULL COMMENT 'ALV = Alvenaria\nMAD = Madeira\nMIS = Mista',
  `tipo` enum('ESC','CON') default NULL COMMENT 'ESC = Escriturado\nCON = Contrato CV',
  `quartos` tinyint(4) default NULL,
  `area` mediumint(9) default NULL,
  `valor` double default NULL,
  `cidade` varchar(45) default NULL,
  `uf` varchar(3) default NULL,
  `endereco` varchar(45) default NULL,
  `numero` varchar(10) default NULL,
  `apto` varchar(10) default NULL,
  `bairro` varchar(45) default NULL,
  `descricao` text,
  PRIMARY KEY  (`id`),
  KEY `idx_imovel_categoria` (`categoria`),
  KEY `fk_imovel_categoria` (`categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `imovel`
--

INSERT INTO `imovel` (`id`, `categoria`, `modalidade`, `construcao`, `tipo`, `quartos`, `area`, `valor`, `cidade`, `uf`, `endereco`, `numero`, `apto`, `bairro`, `descricao`) VALUES
(1, 3, 'V', 'MAD', 'CON', 3, 20, 30000, 'Sapiranga', 'RS', 'Rua Santa Helena', '72', NULL, 'Centenário', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `imovel_categoria`
--

CREATE TABLE `imovel_categoria` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Extraindo dados da tabela `imovel_categoria`
--

INSERT INTO `imovel_categoria` (`id`, `nome`) VALUES
(1, 'Terreno'),
(2, 'Casa'),
(3, 'Apartamento'),
(4, 'Pavilhão'),
(5, 'Sala comercial'),
(6, 'Chácara');

-- --------------------------------------------------------

--
-- Estrutura da tabela `posto`
--

CREATE TABLE `posto` (
  `id` int(11) NOT NULL auto_increment,
  `proprietario` varchar(45) default NULL,
  `endereco` varchar(45) default NULL,
  `cidade` varchar(45) default NULL,
  `estado` varchar(45) default NULL,
  `telefone` varchar(45) default NULL,
  `celular` varchar(45) default NULL,
  `email` varchar(45) default NULL,
  `nome_posto` varchar(45) default NULL,
  `bandeira` varchar(45) default NULL,
  `localizacao` enum('C','R') default NULL COMMENT 'C = Cidade\nR = Rodovia',
  `duracao_contrato` varchar(45) default NULL,
  `tipo` enum('C','P') default NULL COMMENT 'C = ComÃ©rcio\nP = Propriedade',
  `valor_aluguel` double default NULL,
  `tempo_contrato_aluguel` varchar(45) default NULL,
  `situacao_legal` varchar(45) default NULL,
  `vol_venda_mes` double default NULL,
  `vol_gasolina` double default NULL,
  `vol_alcool` double default NULL,
  `vol_diesel` double default NULL,
  `margem_venda` double default NULL COMMENT 'Margem aproximada R$ na venda',
  `funcionarios` int(11) default NULL COMMENT 'Quantidade de funcionÃ¡rios',
  `aberto_24h` tinyint(1) default NULL,
  `loja_conveniencia` tinyint(1) default NULL,
  `troca_oleo` tinyint(1) default NULL,
  `lavagem` tinyint(1) default NULL,
  `venda_vista` varchar(45) default NULL COMMENT 'Porcentagem aproximada venda Ã¡ vista:',
  `venda_prazo` varchar(45) default NULL COMMENT 'A prazo:',
  `venda_cheque` varchar(45) default NULL COMMENT 'Cheque:',
  `venda_cartao` varchar(45) default NULL COMMENT 'CartÃ£o: ',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `posto`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `potencial_imovel`
--

CREATE TABLE `potencial_imovel` (
  `id` int(11) NOT NULL auto_increment,
  `cliente_id` int(11) default NULL,
  `investimento_minimo` double default NULL,
  `investimento_maximo` double default NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_potencial_imovel_cliente` (`cliente_id`),
  KEY `fk_potencial_imovel_cliente` (`cliente_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `potencial_imovel`
--

INSERT INTO `potencial_imovel` (`id`, `cliente_id`, `investimento_minimo`, `investimento_maximo`) VALUES
(1, 1, 50000, 100000),
(2, 2, 75000, 125000);

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `cliente_imovel`
--
ALTER TABLE `cliente_imovel`
  ADD CONSTRAINT `fk_cliente_imovel_cliente_id` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para a tabela `cliente_posto`
--
ALTER TABLE `cliente_posto`
  ADD CONSTRAINT `fk_cliente_posto_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para a tabela `imovel`
--
ALTER TABLE `imovel`
  ADD CONSTRAINT `fk_imovel_categoria` FOREIGN KEY (`categoria`) REFERENCES `imovel_categoria` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para a tabela `potencial_imovel`
--
ALTER TABLE `potencial_imovel`
  ADD CONSTRAINT `potencial_imovel_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
