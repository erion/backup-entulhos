<div id="login">
	<form action="?pagina=login" method="post">
		Login:<br /><input type="text" name="login" size="20" /><br />
		Senha:<br /><input type="password" name="senha" size="20" /><br /><br />
		<div id="botao"><input type="submit" value="&nbsp;Logar&nbsp;" /></div>
		<br /><br /><br />
	</form>
</div>