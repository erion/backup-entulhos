<p>Ganso sem imagem</p>
<p>pegar a imagem</p>