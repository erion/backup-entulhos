<?php
	echo "<img src='images/{$_GET['pagina']}.jpg' />";
	echo $conteudo_arquivo;
?>
